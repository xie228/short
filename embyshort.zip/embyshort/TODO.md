# Emby Short 影视库 App TODO

## 1. Emby 账号登录与网络连接

- [x] 使用 Emby 服务器地址、用户名和密码调用 `/Users/AuthenticateByName`。
- [x] 保存 Emby 返回的 AccessToken、UserId、ServerId 和设备信息；Android 使用 SecureStore，Web Preview 使用兼容存储。
- [x] 统一 API 路径为 `/emby/...`，让用户只填写服务器根地址，例如 `http://192.168.1.4:8096`。
- [x] 401 自动提示重新登录；连接失败提示检查手机到服务器的 IP、端口、Wi-Fi 隔离和防火墙。
- [x] 登录成功后读取用户媒体库、搜索、排序、海报和播放流（文件夹导航待做）。
- [x] 首页统一卡片流合并 Emby / 本地 / OpenList 内容，支持来源筛选。

## 2. 统一来源影视库

- [x] 首页增加媒体来源入口，不再只有 Emby 单一来源。
- [x] 增加手机本地目录选择入口，使用 Android Storage Access Framework 目录授权。
- [x] 支持隐藏目录开关；本地扫描识别常见视频扩展名并保留文件 URI、大小和修改时间。
- [x] 增加 OpenList WebDAV 地址、账号、密码和连接测试；按 `/dav/` 目录读取。
- [x] 把 Emby、本地、OpenList 统一成同一套媒体卡片和播放器数据模型（lib/unified-media.ts）。
- [x] 本地/OpenList 视频按文件名解析标题与年份（lib/video-name.ts，含单元测试）。
- [ ] 本地视频生成缩略图/剧照（需要原生模块，待 Development Build）。
- [ ] SMB 接入 Android 原生 Development Build，支持服务器、共享名、账号密码、目录浏览和视频 Range 播放。

## 3. 播放器与图片

- [ ] 使用 Emby、手机本地、OpenList 和 SMB 的视频 URI 播放。
- [ ] 保持亮色 UI；播放/暂停、快退、快进、封面、剧照控制键统一玻璃拟态胶囊风格。
- [x] 截图添加左上角时间水印；Emby 来源上传到 Primary/Backdrop。
- [ ] 本地/OpenList 来源截图保存到相册（需 expo-media-library，待接入）。
- [ ] Emby 剧照读取、预览、左右切换和删除。
- [x] GIF 动态封面：设备端无法编码时弹窗给出明确提示（当前策略）。

## 4. 交付

- [x] Android 明文局域网 Emby 支持通过 `expo-build-properties.android.usesCleartextTraffic` 配置。
- [ ] 重新构建包含账号登录和多来源能力的 Android APK。
- [ ] 通过 TypeScript、Lint、测试和 Expo Web 预览检查。
- [ ] 保存接受的 checkpoint，提供最新源码 ZIP 和 Android APK 构建说明。

## 5. 本轮完成（2026-11-02）

- [x] 统一媒体模型接入首页与播放器；本地来源可播放 file://，OpenList 走 WebDAV 直链 + Basic 认证头。
- [x] 媒体卡片无封面时显示占位卡（标题 + 播放图标）。
- [x] 播放器新增 GIF 按钮（明确提示设备端不支持编码）。
- [x] 新增 parseVideoName 单元测试；tsc / lint / vitest 全部通过。
- [x] 本地视频缩略图、SMB 原生接入、APK 打包说明见 docs-apk-build.md。
