import { useFocusEffect, useRouter } from "expo-router";
import { useCallback, useMemo, useState } from "react";
import { ActivityIndicator, FlatList, Pressable, RefreshControl, ScrollView, StyleSheet, Text, TextInput, View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";

import { GlassButton } from "@/components/GlassButton";
import { MediaCard } from "@/components/MediaCard";
import { StillGallery } from "@/components/StillGallery";
import { VideoPlayer } from "@/components/VideoPlayer";
import { EmbyClient, type EmbySettings } from "@/lib/emby-client";
import { loadSources, type SourceConfig } from "@/lib/media-sources";
import { loadSettings } from "@/lib/settings-store";
import { embyItemsToMedia, localVideosToMedia, openListVideosToMedia, type MediaSourceKind, type UnifiedMedia } from "@/lib/unified-media";

const SOURCE_FILTERS: { key: MediaSourceKind | "all"; label: string }[] = [
  { key: "all", label: "全部" },
  { key: "emby", label: "Emby" },
  { key: "local", label: "本地" },
  { key: "openlist", label: "OpenList" },
];

export default function HomeScreen() {
  const router = useRouter();
  const [settings, setSettings] = useState<EmbySettings | null>(null);
  const [media, setMedia] = useState<UnifiedMedia[]>([]);
  const [libraries, setLibraries] = useState<{ Id: string; Name?: string }[]>([]);
  const [selectedLibrary, setSelectedLibrary] = useState<string | undefined>();
  const [sourceFilter, setSourceFilter] = useState<MediaSourceKind | "all">("all");
  const [search, setSearch] = useState("");
  const [sort, setSort] = useState("DateCreated");
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState("");
  const [playerMedia, setPlayerMedia] = useState<UnifiedMedia | null>(null);

  const client = useMemo(() => settings?.serverUrl && settings.token && settings.userId ? new EmbyClient(settings) : null, [settings]);

  const reload = useCallback(async (refresh = false) => {
    const saved = await loadSettings();
    setSettings(saved);
    if (refresh) setRefreshing(true); else setLoading(true);
    setError("");
    const collected: UnifiedMedia[] = [];

    // Emby 来源
    let api: EmbyClient | null = null;
    if (saved.serverUrl && saved.token && saved.userId) {
      api = new EmbyClient(saved);
      try {
        const [views, result] = await Promise.all([api.getViews(), api.getItems({ parentId: selectedLibrary, search, sortBy: sort })]);
        setLibraries(views.Items ?? []);
        collected.push(...embyItemsToMedia(result.Items ?? [], api));
      } catch (e) {
        setError(e instanceof Error ? e.message : "连接 Emby 失败");
      }
    }

    // 本地与 OpenList 来源
    try {
      const sources: SourceConfig = await loadSources();
      for (const local of sources.locals) {
        try { collected.push(...localVideosToMedia(local)); } catch { /* 单个来源失败不影响其他 */ }
      }
      for (const openlist of sources.openlists) {
        try { collected.push(...await openListVideosToMedia(openlist)); } catch { /* 单个来源失败不影响其他 */ }
      }
    } catch { /* 来源配置读取失败不阻塞 Emby 展示 */ }

    setMedia(collected);
    setLoading(false);
    setRefreshing(false);
  }, [search, selectedLibrary, sort]);

  useFocusEffect(useCallback(() => {
    const timer = setTimeout(() => void reload(), 0);
    return () => clearTimeout(timer);
  }, [reload]));

  const visibleItems = useMemo(() => {
    const keyword = search.trim().toLowerCase();
    return media
      .filter((item) => (sourceFilter === "all" || item.source === sourceFilter))
      .filter((item) => !keyword || (item.title ?? item.name).toLowerCase().includes(keyword))
      .sort((a, b) => {
        if (a.source !== b.source) return a.source === "emby" ? -1 : b.source === "emby" ? 1 : a.source.localeCompare(b.source);
        return (a.title ?? a.name).localeCompare(b.title ?? b.name);
      });
  }, [media, search, sourceFilter]);

  const availableSources = useMemo(() => new Set(media.map((item) => item.source)), [media]);
  const hasAnySource = media.length > 0;
  const noCredentials = !settings?.serverUrl || !settings.token || !settings.userId;

  if (noCredentials && !hasAnySource && !loading) {
    return <SafeAreaView style={styles.safe}><View style={styles.emptySetup}><View style={styles.logo}><Text style={styles.logoIcon}>▶</Text></View><Text style={styles.heroTitle}>Emby Short</Text><Text style={styles.heroText}>独立媒体浏览器，直接连接你的 Emby 影视库、手机目录或 OpenList。</Text><GlassButton label="配置 Emby" tone="blue" onPress={() => router.push("/settings")} /><GlassButton label="管理媒体来源" onPress={() => router.push("/sources" as never)} /></View></SafeAreaView>;
  }

  return <SafeAreaView style={styles.safe} edges={["top", "left", "right"]}>
    <View style={styles.header}>
      <View><Text style={styles.appTitle}>Emby Short</Text><Text style={styles.subTitle}>{media.length ? `${media.length} 部内容` : "媒体库"}</Text></View>
      <View style={styles.headerActions}><GlassButton icon="▦" compact onPress={() => router.push("/sources" as never)} accessibilityLabel="媒体来源" /><GlassButton icon="⚙" compact onPress={() => router.push("/settings")} accessibilityLabel="设置" /></View>
    </View>
    <View style={styles.searchRow}><TextInput value={search} onChangeText={setSearch} onSubmitEditing={() => void reload()} placeholder="搜索影片或剧集" placeholderTextColor="#94a3b8" style={styles.searchInput} returnKeyType="search" /><GlassButton icon="⌕" compact onPress={() => void reload()} accessibilityLabel="搜索" /></View>
    <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.filtersScroll}>
      <View style={styles.filters}>
        {SOURCE_FILTERS.filter((f) => f.key === "all" || availableSources.has(f.key as MediaSourceKind)).map((filter) => (
          <Pressable key={filter.key} onPress={() => setSourceFilter(filter.key as MediaSourceKind | "all")} style={[styles.filter, sourceFilter === filter.key && styles.filterActive]}>
            <Text style={[styles.filterText, sourceFilter === filter.key && styles.filterTextActive]}>{filter.label}</Text>
          </Pressable>
        ))}
      </View>
      {sourceFilter === "emby" || sourceFilter === "all" ? <View style={styles.filters}>
        <Pressable onPress={() => setSort(sort === "DateCreated" ? "SortName" : "DateCreated")} style={[styles.filter, styles.filterActive]}><Text style={styles.filterTextActive}>{sort === "DateCreated" ? "最新" : "名称"}</Text></Pressable>
        {libraries.slice(0, 3).map((library) => <Pressable key={library.Id} onPress={() => setSelectedLibrary(selectedLibrary === library.Id ? undefined : library.Id)} style={[styles.filter, selectedLibrary === library.Id && styles.filterActive]}><Text numberOfLines={1} style={[styles.filterText, selectedLibrary === library.Id && styles.filterTextActive]}>{library.Name}</Text></Pressable>)}
      </View> : null}
    </ScrollView>
    {error ? <View style={styles.error}><Text style={styles.errorText}>{error}</Text><GlassButton label="重试" compact onPress={() => void reload()} /></View> : null}
    {loading ? <View style={styles.loading}><ActivityIndicator color="#3b82f6" /><Text style={styles.muted}>正在加载媒体库…</Text></View> : <FlatList
      data={visibleItems}
      keyExtractor={(item) => item.id}
      numColumns={2}
      columnWrapperStyle={styles.column}
      contentContainerStyle={styles.grid}
      refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => void reload(true)} tintColor="#3b82f6" />}
      renderItem={({ item }) => <MediaCard item={item} onPress={() => setPlayerMedia(item)} />}
      ListEmptyComponent={<View style={styles.empty}><Text style={styles.emptyTitle}>没有找到内容</Text><Text style={styles.muted}>调整搜索词、来源筛选，或在“媒体来源”中添加本地目录 / OpenList</Text></View>}
    />}
    {playerMedia ? <View style={styles.playerOverlay}><ScrollView contentContainerStyle={styles.playerContent}><VideoPlayer media={playerMedia} client={client} onClose={() => setPlayerMedia(null)} />{playerMedia.source === "emby" && client ? <StillGallery itemId={playerMedia.embyItemId!} client={client} /> : null}</ScrollView></View> : null}
  </SafeAreaView>;
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: "#f0f4f8" },
  header: { paddingHorizontal: 18, paddingTop: 12, paddingBottom: 8, flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  appTitle: { color: "#1e293b", fontSize: 24, fontWeight: "900", letterSpacing: -0.5 },
  subTitle: { color: "#64748b", marginTop: 3, fontSize: 12, fontWeight: "600" },
  headerActions: { flexDirection: "row", gap: 8 },
  searchRow: { flexDirection: "row", alignItems: "center", gap: 8, paddingHorizontal: 18, paddingBottom: 8 },
  searchInput: { flex: 1, height: 44, borderRadius: 22, paddingHorizontal: 16, backgroundColor: "#fff", borderWidth: 1, borderColor: "#e2e8f0", color: "#1e293b" },
  filtersScroll: { paddingHorizontal: 18, paddingBottom: 12, gap: 8, alignItems: "center" },
  filters: { flexDirection: "row", gap: 8 },
  filter: { maxWidth: 112, paddingHorizontal: 12, paddingVertical: 8, borderRadius: 18, backgroundColor: "rgba(255,255,255,.82)", borderWidth: 1, borderColor: "#e2e8f0" },
  filterActive: { backgroundColor: "#eff6ff", borderColor: "#93c5fd" },
  filterText: { color: "#64748b", fontSize: 12, fontWeight: "700" },
  filterTextActive: { color: "#2563eb" },
  grid: { padding: 18, paddingTop: 4, gap: 14, paddingBottom: 40 },
  column: { gap: 14 },
  loading: { flex: 1, alignItems: "center", justifyContent: "center", gap: 10 },
  muted: { color: "#64748b", fontSize: 13 },
  error: { marginHorizontal: 18, marginBottom: 10, padding: 12, borderRadius: 16, backgroundColor: "#fff1f2", borderWidth: 1, borderColor: "#fecdd3", flexDirection: "row", alignItems: "center", gap: 10 },
  errorText: { color: "#be123c", fontSize: 12, flex: 1 },
  emptySetup: { flex: 1, padding: 28, alignItems: "center", justifyContent: "center", gap: 12 },
  logo: { width: 88, height: 88, borderRadius: 28, backgroundColor: "#dbeafe", alignItems: "center", justifyContent: "center", marginBottom: 6 },
  logoIcon: { color: "#2563eb", fontSize: 38, marginLeft: 4 },
  heroTitle: { color: "#1e293b", fontSize: 28, fontWeight: "900" },
  heroText: { color: "#64748b", textAlign: "center", lineHeight: 21, maxWidth: 300, marginBottom: 10 },
  empty: { alignItems: "center", paddingTop: 70, gap: 8 },
  emptyTitle: { color: "#334155", fontSize: 18, fontWeight: "800" },
  playerOverlay: { position: "absolute", top: 0, right: 0, bottom: 0, left: 0, backgroundColor: "#f0f4f8", zIndex: 20 },
  playerContent: { paddingTop: 8, paddingBottom: 36, gap: 16 },
});
