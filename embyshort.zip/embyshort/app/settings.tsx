import { useRouter } from "expo-router";
import { useEffect, useState } from "react";
import { ActivityIndicator, KeyboardAvoidingView, Platform, ScrollView, StyleSheet, Text, TextInput, View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";

import { GlassButton } from "@/components/GlassButton";
import { EmbyClient, type EmbySettings } from "@/lib/emby-client";
import { loadSettings, saveSettings } from "@/lib/settings-store";

type LoginForm = { serverUrl: string; username: string; password: string };

export default function SettingsScreen() {
  const router = useRouter();
  const [saved, setSaved] = useState<EmbySettings | null>(null);
  const [form, setForm] = useState<LoginForm>({ serverUrl: "", username: "", password: "" });
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");
  useEffect(() => { loadSettings().then((value) => { setSaved(value); setForm({ serverUrl: value.serverUrl, username: value.username, password: "" }); }).catch(() => undefined); }, []);
  const update = (key: keyof LoginForm, value: string) => setForm((old) => ({ ...old, [key]: value }));
  const login = async () => {
    const serverUrl = form.serverUrl.trim().replace(/\/+$/, "");
    const username = form.username.trim();
    if (!serverUrl || !username || (!form.password && !saved?.token)) { setMessage("请填写 Emby 地址、用户名和密码"); return; }
    setBusy(true); setMessage("");
    try {
      let session = saved?.token && saved.serverUrl === serverUrl && saved.username === username && !form.password ? { token: saved.token, userId: saved.userId, serverId: saved.serverId, username } : null;
      if (!session) session = await new EmbyClient({ serverUrl, username, token: "", userId: "" }).login(username, form.password);
      const settings: EmbySettings = { serverUrl, username: session.username, token: session.token, userId: session.userId, serverId: session.serverId, deviceId: "emby-short-android" };
      const client = new EmbyClient(settings);
      const info = await client.testConnection();
      await saveSettings(settings);
      setMessage(`登录成功${info.ServerName ? ` · ${info.ServerName}` : ""}`);
      setTimeout(() => router.replace("/"), 450);
    } catch (error) {
      const raw = error instanceof Error ? error.message : "登录失败";
      setMessage(raw.includes("ConnectException") || raw.includes("Network request failed") || raw.includes("fetch failed") ? "无法连接 Emby。请确认手机能打开该地址，并检查 IP、端口和 Wi-Fi 隔离。" : raw);
    } finally { setBusy(false); }
  };
  return <SafeAreaView style={styles.safe}><KeyboardAvoidingView behavior={Platform.OS === "ios" ? "padding" : undefined} style={styles.flex}><ScrollView contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled"><View style={styles.top}><GlassButton icon="‹" compact onPress={() => router.back()} accessibilityLabel="返回" /><View><Text style={styles.title}>连接 Emby</Text><Text style={styles.subtitle}>使用 Emby 账号登录，不再需要 API Key</Text></View></View><View style={styles.card}><Text style={styles.label}>服务器地址</Text><TextInput autoCapitalize="none" autoCorrect={false} value={form.serverUrl} onChangeText={(value) => update("serverUrl", value)} placeholder="http://192.168.1.4:8096" placeholderTextColor="#94a3b8" style={styles.input} /><Text style={styles.helper}>手机必须能访问这个地址；Emby 默认端口通常是 8096。</Text><Text style={styles.label}>Emby 用户名</Text><TextInput autoCapitalize="none" autoCorrect={false} value={form.username} onChangeText={(value) => update("username", value)} placeholder="用户名" placeholderTextColor="#94a3b8" style={styles.input} /><Text style={styles.label}>Emby 密码</Text><TextInput autoCapitalize="none" autoCorrect={false} secureTextEntry value={form.password} onChangeText={(value) => update("password", value)} placeholder={saved?.token ? "留空以使用已保存登录" : "密码"} placeholderTextColor="#94a3b8" style={styles.input} /><Text style={styles.note}>密码只用于登录；App 保存的是 Emby 返回的会话 token。Web 预览使用本地存储，Android 使用安全存储。</Text><GlassButton label={busy ? "登录中…" : "登录并进入影视库"} tone="blue" onPress={() => void login()} disabled={busy} />{busy ? <ActivityIndicator color="#3b82f6" /> : null}{message ? <Text style={[styles.message, message.startsWith("登录成功") ? styles.success : styles.failure]}>{message}</Text> : null}</View><View style={styles.tip}><Text style={styles.tipTitle}>连接失败时先检查</Text><Text style={styles.tipText}>用手机浏览器打开服务器地址；确认手机和 Emby 在同一 Wi-Fi，路由器没有开启客户端隔离，并确认端口不是被防火墙拦截。</Text></View></ScrollView></KeyboardAvoidingView></SafeAreaView>;
}

const styles = StyleSheet.create({ safe: { flex: 1, backgroundColor: "#f0f4f8" }, flex: { flex: 1 }, content: { padding: 18, gap: 18 }, top: { flexDirection: "row", alignItems: "center", gap: 12 }, title: { color: "#1e293b", fontSize: 23, fontWeight: "900" }, subtitle: { color: "#64748b", fontSize: 12, marginTop: 3 }, card: { padding: 18, gap: 10, borderRadius: 24, backgroundColor: "rgba(255,255,255,.88)", borderWidth: 1, borderColor: "#e2e8f0", shadowColor: "#0f172a", shadowOpacity: .08, shadowRadius: 12, shadowOffset: { width: 0, height: 5 }, elevation: 2 }, label: { color: "#334155", fontSize: 12, fontWeight: "800", marginTop: 4 }, input: { height: 48, borderRadius: 16, paddingHorizontal: 14, color: "#1e293b", backgroundColor: "#f8fafc", borderWidth: 1, borderColor: "#dbe5f2" }, helper: { color: "#64748b", fontSize: 11, marginTop: -3 }, note: { color: "#64748b", fontSize: 11, lineHeight: 17, marginVertical: 4 }, message: { fontSize: 12, fontWeight: "700" }, success: { color: "#15803d" }, failure: { color: "#be123c" }, tip: { padding: 16, borderRadius: 20, backgroundColor: "#eff6ff", borderWidth: 1, borderColor: "#bfdbfe", gap: 6 }, tipTitle: { color: "#1d4ed8", fontWeight: "900" }, tipText: { color: "#475569", fontSize: 12, lineHeight: 18 } });
