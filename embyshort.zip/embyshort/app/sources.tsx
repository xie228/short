import { useEffect, useState } from "react";
import { KeyboardAvoidingView, Platform, Pressable, ScrollView, StyleSheet, Switch, Text, TextInput, View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";

import { GlassButton } from "@/components/GlassButton";
import { listOpenListDirectory, loadSources, pickLocalDirectory, saveSources, type LocalSource, type OpenListSource, type SourceConfig } from "@/lib/media-sources";
import { useRouter } from "expo-router";

export default function SourcesScreen() {
  const router = useRouter();
  const [config, setConfig] = useState<SourceConfig>({ locals: [], openlists: [] });
  const [includeHidden, setIncludeHidden] = useState(false);
  const [openlist, setOpenlist] = useState({ url: "", username: "", password: "" });
  const [message, setMessage] = useState("");
  useEffect(() => { loadSources().then(setConfig).catch(() => undefined); }, []);

  const addLocal = async () => {
    try {
      const source = await pickLocalDirectory(includeHidden);
      if (!source) return;
      const next = { ...config, locals: [...config.locals.filter((item) => item.uri !== source.uri), source] };
      setConfig(next); await saveSources(next); setMessage(`已添加手机目录：${source.name}`);
    } catch (error) { setMessage(error instanceof Error ? error.message : "手机目录选择失败；Android APK 中才能使用系统目录授权"); }
  };

  const addOpenlist = async () => {
    const normalized = { url: openlist.url.trim().replace(/\/+$/, ""), username: openlist.username.trim(), password: openlist.password };
    if (!normalized.url) { setMessage("请填写 OpenList 地址"); return; }
    try {
      await listOpenListDirectory({ id: `openlist:${normalized.url}`, name: "OpenList", ...normalized, includeHidden });
      const source: OpenListSource = { id: `openlist:${normalized.url}`, name: "OpenList", ...normalized, includeHidden };
      const next = { ...config, openlists: [...config.openlists.filter((item) => item.id !== source.id), source] };
      setConfig(next); await saveSources(next); setMessage("OpenList WebDAV 连接成功");
    } catch (error) { setMessage(error instanceof Error ? error.message : "OpenList 连接失败；请检查 /dav、账号权限和 Web Proxy 设置"); }
  };

  const removeLocal = async (source: LocalSource) => { const next = { ...config, locals: config.locals.filter((item) => item.id !== source.id) }; setConfig(next); await saveSources(next); };
  const removeOpenlist = async (source: OpenListSource) => { const next = { ...config, openlists: config.openlists.filter((item) => item.id !== source.id) }; setConfig(next); await saveSources(next); };

  return <SafeAreaView style={styles.safe}><KeyboardAvoidingView style={styles.flex} behavior={Platform.OS === "ios" ? "padding" : undefined}><ScrollView contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled"><View style={styles.top}><GlassButton icon="‹" compact onPress={() => router.back()} accessibilityLabel="返回" /><View><Text style={styles.title}>媒体来源</Text><Text style={styles.subtitle}>Emby、手机本地和 OpenList 统一进入影视库</Text></View></View><View style={styles.card}><View style={styles.row}><View style={styles.grow}><Text style={styles.cardTitle}>手机本地目录</Text><Text style={styles.muted}>使用 Android 系统目录授权读取视频</Text></View><Switch value={includeHidden} onValueChange={setIncludeHidden} trackColor={{ false: "#cbd5e1", true: "#93c5fd" }} thumbColor={includeHidden ? "#2563eb" : "#f8fafc"} /></View><Pressable style={styles.hiddenRow} onPress={() => setIncludeHidden((value) => !value)}><Text style={styles.hiddenIcon}>{includeHidden ? "☑" : "□"}</Text><Text style={styles.muted}>显示隐藏文件夹（以 . 或 _ 开头）</Text></Pressable><GlassButton label="选择手机目录" tone="blue" onPress={() => void addLocal()} />{config.locals.map((source) => <View key={source.id} style={styles.sourceRow}><Text style={styles.sourceName}>📁 {source.name}</Text><GlassButton icon="×" compact onPress={() => void removeLocal(source)} accessibilityLabel={`移除 ${source.name}`} /></View>)}</View><View style={styles.card}><Text style={styles.cardTitle}>OpenList WebDAV</Text><Text style={styles.muted}>地址填写 OpenList 根地址，App 会访问 /dav/</Text><TextInput autoCapitalize="none" autoCorrect={false} value={openlist.url} onChangeText={(value) => setOpenlist((old) => ({ ...old, url: value }))} placeholder="http://192.168.1.10:5244" placeholderTextColor="#94a3b8" style={styles.input} /><TextInput autoCapitalize="none" autoCorrect={false} value={openlist.username} onChangeText={(value) => setOpenlist((old) => ({ ...old, username: value }))} placeholder="OpenList 用户名（可留空使用 guest）" placeholderTextColor="#94a3b8" style={styles.input} /><TextInput autoCapitalize="none" autoCorrect={false} secureTextEntry value={openlist.password} onChangeText={(value) => setOpenlist((old) => ({ ...old, password: value }))} placeholder="OpenList 密码" placeholderTextColor="#94a3b8" style={styles.input} /><GlassButton label="测试并添加 OpenList" tone="blue" onPress={() => void addOpenlist()} />{config.openlists.map((source) => <View key={source.id} style={styles.sourceRow}><Text style={styles.sourceName}>☁ {source.url}</Text><GlassButton icon="×" compact onPress={() => void removeOpenlist(source)} accessibilityLabel="移除 OpenList" /></View>)}</View>{message ? <View style={styles.notice}><Text style={styles.noticeText}>{message}</Text></View> : null}<View style={styles.tip}><Text style={styles.tipTitle}>关于 SMB</Text><Text style={styles.tipText}>SMB 需要 Android 原生 Development Build。当前阶段先支持 OpenList WebDAV；SMB 会在下一阶段加入原生连接模块。</Text></View></ScrollView></KeyboardAvoidingView></SafeAreaView>;
}

const styles = StyleSheet.create({ safe: { flex: 1, backgroundColor: "#f0f4f8" }, flex: { flex: 1 }, content: { padding: 18, gap: 16 }, top: { flexDirection: "row", alignItems: "center", gap: 12 }, title: { color: "#1e293b", fontSize: 23, fontWeight: "900" }, subtitle: { color: "#64748b", fontSize: 12, marginTop: 3 }, card: { padding: 18, borderRadius: 24, gap: 12, backgroundColor: "rgba(255,255,255,.9)", borderWidth: 1, borderColor: "#e2e8f0" }, row: { flexDirection: "row", alignItems: "center", gap: 10 }, grow: { flex: 1 }, cardTitle: { color: "#1e293b", fontSize: 16, fontWeight: "900" }, muted: { color: "#64748b", fontSize: 12, lineHeight: 18 }, hiddenRow: { flexDirection: "row", alignItems: "center", gap: 8 }, hiddenIcon: { color: "#2563eb", fontSize: 18 }, input: { height: 46, borderRadius: 15, paddingHorizontal: 14, color: "#1e293b", backgroundColor: "#f8fafc", borderWidth: 1, borderColor: "#dbe5f2" }, sourceRow: { flexDirection: "row", alignItems: "center", gap: 8, paddingTop: 4 }, sourceName: { flex: 1, color: "#334155", fontSize: 12, fontWeight: "700" }, notice: { padding: 12, borderRadius: 16, backgroundColor: "#eff6ff", borderWidth: 1, borderColor: "#bfdbfe" }, noticeText: { color: "#1d4ed8", fontSize: 12, fontWeight: "700" }, tip: { padding: 16, borderRadius: 20, backgroundColor: "#f8fafc", borderWidth: 1, borderColor: "#e2e8f0", gap: 6 }, tipTitle: { color: "#334155", fontWeight: "900" }, tipText: { color: "#64748b", fontSize: 12, lineHeight: 18 } });
