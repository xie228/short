import { Pressable, StyleSheet, Text } from "react-native";

type Props = {
  label?: string;
  icon?: string;
  onPress: () => void;
  disabled?: boolean;
  compact?: boolean;
  tone?: "light" | "blue" | "danger";
  accessibilityLabel?: string;
};

export function GlassButton({ label, icon, onPress, disabled, compact, tone = "light", accessibilityLabel }: Props) {
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={accessibilityLabel ?? label}
      disabled={disabled}
      onPress={onPress}
      style={({ pressed }) => [
        styles.button,
        compact && styles.compact,
        tone === "blue" && styles.blue,
        tone === "danger" && styles.danger,
        pressed && styles.pressed,
        disabled && styles.disabled,
      ]}
    >
      {icon ? <Text style={[styles.icon, compact && styles.compactIcon]}>{icon}</Text> : null}
      {label ? <Text style={styles.label}>{label}</Text> : null}
    </Pressable>
  );
}

const styles = StyleSheet.create({
  button: {
    minWidth: 72,
    height: 46,
    paddingHorizontal: 16,
    borderRadius: 24,
    alignItems: "center",
    justifyContent: "center",
    flexDirection: "row",
    gap: 6,
    backgroundColor: "rgba(255,255,255,0.86)",
    borderWidth: 1,
    borderColor: "rgba(148,163,184,0.56)",
    shadowColor: "#0f172a",
    shadowOpacity: 0.14,
    shadowRadius: 10,
    shadowOffset: { width: 0, height: 4 },
    elevation: 3,
  },
  compact: { minWidth: 52, width: 52, height: 40, paddingHorizontal: 4 },
  blue: { backgroundColor: "rgba(239,246,255,0.96)", borderColor: "#93c5fd" },
  danger: { borderColor: "#fecaca", backgroundColor: "rgba(254,242,242,0.94)" },
  pressed: { transform: [{ scale: 0.94 }], backgroundColor: "rgba(226,232,240,0.98)" },
  disabled: { opacity: 0.45 },
  icon: { fontSize: 21, lineHeight: 23, color: "#1e293b", fontWeight: "800" },
  compactIcon: { fontSize: 20 },
  label: { color: "#1e293b", fontSize: 13, fontWeight: "800" },
});
