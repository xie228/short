import { Image } from "expo-image";
import { Pressable, StyleSheet, Text, View } from "react-native";

import type { UnifiedMedia } from "@/lib/unified-media";
import { sourceLabel } from "@/lib/unified-media";

function formatDuration(ticks?: number) {
  if (!ticks) return "";
  const total = Math.floor(ticks / 10_000_000);
  const hours = Math.floor(total / 3600);
  const minutes = Math.floor((total % 3600) / 60);
  return hours ? `${hours}小时${minutes}分` : `${minutes}分钟`;
}

type Props = { item: UnifiedMedia; onPress: () => void };

export function MediaCard({ item, onPress }: Props) {
  return (
    <Pressable onPress={onPress} style={({ pressed }) => [styles.card, pressed && styles.pressed]}>
      {item.imageUrl ? (
        <Image source={item.imageUrl} contentFit="cover" transition={180} style={styles.poster} />
      ) : (
        <View style={[styles.poster, styles.posterFallback]}>
          <Text style={styles.posterIcon}>▶</Text>
          <Text numberOfLines={2} style={styles.posterName}>{item.title ?? item.name}</Text>
        </View>
      )}
      <View style={styles.info}>
        <Text numberOfLines={2} style={styles.title}>{item.title ?? item.name}</Text>
        <Text style={styles.meta}>
          {sourceLabel(item.source)}
          {item.year ? ` · ${item.year}` : ""}
          {formatDuration(item.durationTicks) ? ` · ${formatDuration(item.durationTicks)}` : ""}
        </Text>
      </View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  card: { flex: 1, minWidth: 0, backgroundColor: "#fff", borderRadius: 18, overflow: "hidden", borderWidth: 1, borderColor: "#e2e8f0", shadowColor: "#0f172a", shadowOpacity: 0.08, shadowRadius: 10, shadowOffset: { width: 0, height: 4 }, elevation: 2 },
  pressed: { transform: [{ scale: 0.985 }], opacity: 0.9 },
  poster: { width: "100%", aspectRatio: 0.68, backgroundColor: "#e8eef5" },
  posterFallback: { alignItems: "center", justifyContent: "center", gap: 8, backgroundColor: "#dbeafe", padding: 12 },
  posterIcon: { color: "#2563eb", fontSize: 30 },
  posterName: { color: "#1d4ed8", fontSize: 12, fontWeight: "800", textAlign: "center" },
  info: { padding: 10, gap: 5 },
  title: { color: "#1e293b", fontSize: 14, lineHeight: 19, fontWeight: "800" },
  meta: { color: "#64748b", fontSize: 11, fontWeight: "600" },
});
