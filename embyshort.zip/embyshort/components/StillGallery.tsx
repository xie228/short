import { Image } from "expo-image";
import { useCallback, useEffect, useState } from "react";
import { Alert, Modal, Pressable, ScrollView, StyleSheet, Text, View } from "react-native";

import { GlassButton } from "@/components/GlassButton";
import type { EmbyClient, EmbyImage } from "@/lib/emby-client";

function confirmDelete(message: string, onConfirm: () => void) {
  if (typeof window !== "undefined" && typeof window.confirm === "function") {
    if (window.confirm(message)) onConfirm();
    return;
  }
  Alert.alert("删除剧照", message, [{ text: "取消", style: "cancel" }, { text: "删除", style: "destructive", onPress: onConfirm }]);
}

type Props = { itemId: string; client: EmbyClient };

export function StillGallery({ itemId, client }: Props) {
  const [items, setItems] = useState<EmbyImage[]>([]);
  const [selected, setSelected] = useState<number | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const load = useCallback(async () => {
    setLoading(true); setError("");
    try { setItems(await client.getBackdrops(itemId)); } catch (e) { setError(e instanceof Error ? e.message : "剧照读取失败"); } finally { setLoading(false); }
  }, [client, itemId]);
  useEffect(() => { const timer = setTimeout(() => void load(), 0); return () => clearTimeout(timer); }, [load]);

  const remove = (index: number) => confirmDelete("确定从 Emby 删除这张剧照吗？", async () => {
    try { await client.deleteBackdrop(itemId, index); setSelected(null); await load(); } catch (e) { Alert.alert("删除失败", e instanceof Error ? e.message : "无法删除剧照"); }
  });

  if (loading) return <Text style={styles.muted}>正在读取剧照…</Text>;
  if (error) return <Text style={styles.error}>{error}</Text>;
  return <View style={styles.wrap}>
    <View style={styles.heading}><Text style={styles.headingText}>Emby 剧照</Text><Text style={styles.count}>{items.length} 张</Text></View>
    {items.length ? <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.row}>{items.map((image, index) => <View key={`${image.Url}-${index}`} style={styles.card}><Pressable onPress={() => setSelected(index)}><Image source={image.Url} contentFit="cover" style={styles.image} /></Pressable><Pressable style={styles.delete} onPress={() => remove(image.DeleteIndex ?? index)}><Text style={styles.deleteText}>×</Text></Pressable></View>)}</ScrollView> : <Text style={styles.muted}>还没有 Emby 剧照</Text>}
    <Modal visible={selected !== null} transparent animationType="fade" onRequestClose={() => setSelected(null)}>
      <View style={styles.modal}><View style={styles.modalCard}><View style={styles.modalTop}><GlassButton icon="×" compact onPress={() => setSelected(null)} accessibilityLabel="关闭剧照" /><Text style={styles.modalCount}>{selected === null ? "" : `${selected + 1} / ${items.length}`}</Text><GlassButton icon="⌫" compact onPress={() => selected !== null && remove(items[selected]?.DeleteIndex ?? selected)} accessibilityLabel="删除剧照" /></View>{selected !== null && items[selected] ? <Image source={items[selected].Url} contentFit="contain" style={styles.largeImage} /> : null}<View style={styles.nav}><GlassButton icon="‹" compact onPress={() => setSelected(selected === null ? null : (selected - 1 + items.length) % items.length)} accessibilityLabel="上一张" /><GlassButton icon="›" compact onPress={() => setSelected(selected === null ? null : (selected + 1) % items.length)} accessibilityLabel="下一张" /></View></View></View>
    </Modal>
  </View>;
}

const styles = StyleSheet.create({
  wrap: { gap: 10 },
  heading: { flexDirection: "row", alignItems: "baseline", gap: 8 },
  headingText: { color: "#1e293b", fontSize: 15, fontWeight: "900" },
  count: { color: "#64748b", fontSize: 11 },
  row: { gap: 10, paddingVertical: 4 },
  card: { width: 132, height: 84, borderRadius: 14, overflow: "hidden", backgroundColor: "#dbeafe", position: "relative", borderWidth: 1, borderColor: "#bfdbfe" },
  image: { width: "100%", height: "100%" },
  delete: { position: "absolute", top: 5, right: 5, width: 28, height: 28, borderRadius: 14, backgroundColor: "rgba(15,23,42,.72)", alignItems: "center", justifyContent: "center" },
  deleteText: { color: "#fff", fontSize: 19, lineHeight: 20 },
  muted: { color: "#64748b", fontSize: 12 },
  error: { color: "#be123c", fontSize: 12 },
  modal: { flex: 1, backgroundColor: "rgba(15,23,42,.65)", justifyContent: "center", padding: 16 },
  modalCard: { backgroundColor: "#f8fafc", borderRadius: 24, padding: 14, gap: 12, maxHeight: "90%" },
  modalTop: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  modalCount: { color: "#475569", fontWeight: "800" },
  largeImage: { width: "100%", height: 360, borderRadius: 16, backgroundColor: "#e2e8f0" },
  nav: { flexDirection: "row", justifyContent: "center", gap: 20 },
});
