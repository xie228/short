import { useEvent } from "expo";
import { VideoView, useVideoPlayer } from "expo-video";
import { useEffect, useMemo, useRef, useState } from "react";
import { Alert, Dimensions, Modal, Pressable, StyleSheet, Text, View } from "react-native";
import { captureRef } from "react-native-view-shot";

import { GlassButton } from "@/components/GlassButton";
import type { EmbyClient } from "@/lib/emby-client";
import { sourceLabel, type UnifiedMedia } from "@/lib/unified-media";

function formatTime(seconds: number) {
  const total = Math.max(0, Math.floor(seconds));
  const h = Math.floor(total / 3600);
  const m = Math.floor((total % 3600) / 60);
  const s = total % 60;
  return h ? `${h}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}` : `${m}:${String(s).padStart(2, "0")}`;
}

type Props = { media: UnifiedMedia; client?: EmbyClient | null; onClose: () => void };

export function VideoPlayer({ media, client, onClose }: Props) {
  const stageRef = useRef<View>(null);
  const [controls, setControls] = useState(true);
  const [busy, setBusy] = useState(false);
  const [captureKind, setCaptureKind] = useState<"Primary" | "Backdrop" | null>(null);
  const [capturePreview, setCapturePreview] = useState<string | null>(null);
  const canUpload = media.source === "emby" && Boolean(client && media.embyItemId);
  const source = useMemo(() => ({ uri: media.streamUri, headers: media.headers }), [media.streamUri, media.headers]);
  const player = useVideoPlayer(source, (instance) => {
    instance.timeUpdateEventInterval = 0.25;
    instance.keepScreenOnWhilePlaying = true;
    instance.audioMixingMode = "doNotMix";
  });
  const { isPlaying } = useEvent(player, "playingChange", { isPlaying: player.playing });
  const { currentTime } = useEvent(player, "timeUpdate", { currentTime: 0, currentLiveTimestamp: null, currentOffsetFromLive: null, bufferedPosition: 0 });
  const time = currentTime;
  const duration = player.duration > 0 ? player.duration : Math.max(1, (media.durationTicks ?? 0) / 10_000_000);
  const playerRef = useRef(player);

  useEffect(() => {
    player.play();
    return () => player.pause();
  }, [player]);

  const togglePlayback = () => (isPlaying ? player.pause() : player.play());
  const seek = (delta: number) => { player.seekBy(Math.max(-player.currentTime, Math.min(delta, duration - player.currentTime))); };

  const requestGifCover = () => {
    Alert.alert(
      "GIF 动态封面暂不支持",
      "当前设备端无法完成 GIF 编码（需要原生模块，独立 App 不携带 Termux/Python 后端）。请继续使用 JPG 封面或剧照；GIF 能力会在后续原生构建版本中加入。",
      [{ text: "知道了" }],
    );
  };

  const captureStill = async (kind: "Primary" | "Backdrop") => {
    if (busy) return;
    if (!canUpload) {
      Alert.alert("暂不支持上传", `${sourceLabel(media.source)}来源的截图暂不能上传到 Emby，后续版本会支持保存到相册或来源目录。`);
      return;
    }
    setBusy(true);
    const wasPlaying = player.playing;
    try {
      player.pause();
      setCaptureKind(kind);
      await new Promise((resolve) => setTimeout(resolve, 140));
      if (!stageRef.current) throw new Error("播放器画面尚未准备好");
      const base64 = await captureRef(stageRef, { format: "jpg", quality: 0.94, result: "base64" });
      if (kind === "Backdrop") setCapturePreview(`data:image/jpeg;base64,${base64}`);
      await client!.uploadImage(media.embyItemId!, kind, base64);
      Alert.alert("已完成", kind === "Primary" ? "封面已上传到 Emby" : "剧照已上传到 Emby");
      if (wasPlaying) player.play();
    } catch (error) {
      Alert.alert("截图失败", error instanceof Error ? error.message : "当前设备无法抓取视频画面");
    } finally {
      if (wasPlaying && !player.playing) player.play();
      setCaptureKind(null);
      setBusy(false);
    }
  };

  return (
    <View style={styles.root}>
      <View ref={stageRef} collapsable={false} style={styles.stage}>
        <VideoView
          player={player}
          style={StyleSheet.absoluteFill}
          contentFit="contain"
          nativeControls={false}
          surfaceType="textureView"
          allowsPictureInPicture
          fullscreenOptions={{ enable: true, orientation: "landscape" }}
        />
        <Pressable style={StyleSheet.absoluteFill} onPress={() => setControls((value) => !value)} />
        {captureKind === "Backdrop" ? <View pointerEvents="none" style={styles.watermark}><Text style={styles.watermarkText}>{formatTime(time)}</Text></View> : null}
      </View>
      {controls ? <View style={styles.panel}>
        <View style={styles.headingRow}>
          <View style={styles.headingText}>
            <Text numberOfLines={1} style={styles.title}>{media.title ?? media.name}</Text>
            <Text style={styles.sub}>{formatTime(time)} / {formatTime(duration)}{media.year ? ` · ${media.year}` : ""}</Text>
          </View>
          <GlassButton icon="×" compact onPress={onClose} accessibilityLabel="关闭播放器" />
        </View>
        <View style={styles.progressTrack}><View style={[styles.progressFill, { width: `${Math.min(100, (time / Math.max(duration, 1)) * 100)}%` }]} /></View>
        <View style={styles.controlsRow}>
          <GlassButton icon="⏪" compact onPress={() => seek(-10)} accessibilityLabel="快退十秒" />
          <GlassButton icon={isPlaying ? "❚❚" : "▶"} compact onPress={togglePlayback} accessibilityLabel={isPlaying ? "暂停" : "播放"} />
          <GlassButton icon="⏩" compact onPress={() => seek(10)} accessibilityLabel="快进十秒" />
          <GlassButton icon="▣" compact onPress={() => void captureStill("Primary")} disabled={busy || !canUpload} accessibilityLabel={canUpload ? "上传封面" : "封面仅 Emby 来源可上传"} />
          <GlassButton icon="▧" compact onPress={() => void captureStill("Backdrop")} disabled={busy || !canUpload} accessibilityLabel={canUpload ? "截取剧照" : "剧照仅 Emby 来源可上传"} />
          <GlassButton icon="GIF" compact onPress={requestGifCover} accessibilityLabel="GIF 动态封面" />
        </View>
        <View style={styles.secondaryRow}>
          <GlassButton label="−10" compact onPress={() => seek(-10)} />
          <GlassButton label="速度" compact onPress={() => { playerRef.current.playbackRate = playerRef.current.playbackRate >= 2 ? 1 : playerRef.current.playbackRate + 0.5; }} />
          <GlassButton label="+10" compact onPress={() => seek(10)} />
          {!canUpload ? <GlassButton label={`${sourceLabel(media.source)}来源`} compact onPress={() => setControls(false)} disabled /> : null}
        </View>
      </View> : null}
      <Modal transparent visible={Boolean(capturePreview)} animationType="fade" onRequestClose={() => setCapturePreview(null)}>
        <Pressable style={styles.modalBackdrop} onPress={() => setCapturePreview(null)}>
          {capturePreview ? <View style={styles.previewCard}><Text style={styles.previewLabel}>剧照预览 · 左上角时间水印</Text><View style={styles.previewImage}><Text style={styles.previewImageText}>已生成并上传</Text></View></View> : null}
        </Pressable>
      </Modal>
    </View>
  );
}

const { width } = Dimensions.get("window");
const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: "#f0f4f8" },
  stage: { width: "100%", aspectRatio: width > 420 ? 16 / 9 : 1.2, backgroundColor: "#0f172a", overflow: "hidden", borderRadius: 24 },
  panel: { padding: 12, gap: 10, backgroundColor: "rgba(248,250,252,0.96)" },
  headingRow: { flexDirection: "row", alignItems: "center", gap: 10 },
  headingText: { flex: 1, gap: 2 },
  title: { color: "#1e293b", fontSize: 16, fontWeight: "800" },
  sub: { color: "#64748b", fontSize: 11, fontWeight: "600" },
  progressTrack: { height: 12, borderRadius: 999, overflow: "hidden", backgroundColor: "rgba(148,163,184,0.25)", borderWidth: 1, borderColor: "rgba(148,163,184,0.45)" },
  progressFill: { height: "100%", borderRadius: 999, backgroundColor: "#3b82f6" },
  controlsRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", gap: 6 },
  secondaryRow: { flexDirection: "row", justifyContent: "center", gap: 10 },
  watermark: { position: "absolute", top: 14, left: 14, paddingHorizontal: 8, paddingVertical: 4, borderRadius: 8, backgroundColor: "rgba(0,0,0,0.5)" },
  watermarkText: { color: "#fff", fontSize: 12, fontWeight: "800" },
  modalBackdrop: { flex: 1, backgroundColor: "rgba(15,23,42,0.55)", alignItems: "center", justifyContent: "center", padding: 20 },
  previewCard: { width: "100%", maxWidth: 420, padding: 18, borderRadius: 24, backgroundColor: "#fff", gap: 14 },
  previewLabel: { color: "#1e293b", fontSize: 14, fontWeight: "800" },
  previewImage: { aspectRatio: 16 / 9, borderRadius: 16, backgroundColor: "#dbeafe", alignItems: "center", justifyContent: "center" },
  previewImageText: { color: "#2563eb", fontWeight: "800" },
});
