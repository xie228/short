# Emby Short APK 构建说明

## 方式一：EAS Build（推荐，云端构建）

```bash
npm install -g eas-cli
eas login
eas build --platform android --profile preview
```

`eas.json` 中已有 profile；构建完成后下载 APK 安装。首次构建需在 Expo 账号中关联项目。

## 方式二：本地构建（需要 Android SDK / JDK 17）

```bash
pnpm install
npx expo prebuild --platform android   # 生成 android/ 目录
cd android
./gradlew assembleRelease              # 产物：android/app/build/outputs/apk/release/
```

签名：在 `android/app/build.gradle` 配置 release signingConfig，或先用 debug 签名测试。

## 注意事项

1. **必须使用 Development/Release 原生构建**：手机本地目录选择（SAF）、未来的 SMB 接入都依赖原生模块，Expo Go 无法运行完整功能。
2. **明文 HTTP**：`app.config.ts` 已通过 `expo-build-properties` 开启 `usesCleartextTraffic`，允许局域网 `http://` 的 Emby / OpenList 地址。
3. **本地视频缩略图**：当前为占位卡设计；若需真实缩略图，需加入原生模块（如 `react-native-thumbnail`）后重新 prebuild。
4. **SMB**：计划使用 `react-native-smb` 类原生模块，同样需要 Development Build，本次未实现。
5. **GIF 动态封面**：设备端 GIF 编码需要原生编码器，当前点击 GIF 按钮给出明确提示。
