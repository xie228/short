# Emby Short 影视库 App 调研与重设计

## 已确认的官方接口事实

Emby REST API 支持两种认证方式：API Key 和用户认证。用户认证适用于交互式客户端，登录接口是 `POST /Users/AuthenticateByName`；成功后返回 `AccessToken`，后续请求使用 `X-Emby-Token`，并在 Authorization 中携带当前用户 ID、客户端名、设备名、设备 ID 和版本。401 通常表示 token 被撤销，客户端应回到登录页。来源：

- https://dev.emby.media/doc/restapi/index.html
- https://dev.emby.media/doc/restapi/User-Authentication.html

Emby API 地址格式为 `http[s]://hostname:port/emby/{apipath}`。媒体项目、播放流、图片标签、Backdrop 和用户上下文应统一由登录后的 token 访问。Emby 官方元数据说明也强调：文字资料、海报和剧照可能来自不同资源，客户端应区分媒体实体、字段映射和图片角色。来源：

- https://emby.media/learn/articles/metadata-discovery/services/Metadata-Provider-Workflow.html

## 网络错误解释

`java.net.ConnectException: Failed to connect to /192.168.1.4:8096` 发生在 TCP 连接阶段，说明手机到 Emby 主机或端口不通，早于账号密码认证。需要确认手机与服务器在同一局域网、Emby 监听局域网地址、端口确实是 8096、路由器没有隔离 Wi-Fi 客户端，且手机浏览器能打开 `http://192.168.1.4:8096`。如果浏览器也打不开，换认证方式不会解决问题。

## OpenList 接入结论

OpenList 官方支持通过 WebDAV 暴露文件。默认地址格式为 `http[s]://域名:端口/dav/`，使用 OpenList 网页账号密码；只播放文件需要 WebDAV Read 权限。OpenList 文档还说明，视频代理播放需要启用 Web Proxy 或 WebDAV Native Proxy。来源：

- https://doc.oplist.org/guide/advanced/webdav
- https://doc.oplist.org/guide/drivers/openlist

因此 App 第一版应把 OpenList 作为 WebDAV 文件源：目录浏览、视频播放、图片读取和隐藏目录开关可以直接基于 HTTP/WebDAV 实现。OpenList 自身支持的后端由 OpenList 负责，App 不需要为每种网盘单独实现驱动。

## 手机本地目录接入结论

Android 官方 Storage Access Framework 支持 `ACTION_OPEN_DOCUMENT_TREE`，用户选择目录后 App 可以获得长期访问授权；Downloads、Images、Videos、USB 和其他 DocumentProvider 都可以出现在系统选择器中。来源：

- https://developer.android.com/guide/topics/providers/document-provider

本地媒体浏览可分为两层：系统目录授权和 App 内媒体索引。索引需要识别视频扩展名、读取容器元数据、生成缩略图，并允许隐藏目录开关。Android 原生能力需要通过 Expo Module 或开发构建接入；Expo Web Preview 不能验证原生目录授权。

## SMB 接入结论

SMB 不等同于 Android SAF。要在 App 内直接输入 SMB 主机、共享名、用户名和密码并浏览，需要 Android 原生 SMB 客户端库或原生模块。建议放在第二阶段，使用 Expo Development Build/自定义原生模块，不把 SMB 伪装成普通 HTTP。若用户已在系统文件管理器中挂载 SMB，第一阶段可以通过 SAF 读取其暴露的目录。

## 重设计方案

App 改为“影视库聚合器”，不再以“仅连接 Emby”为唯一入口。首页分为全部媒体、Emby、手机本地、OpenList、SMB 五类来源；统一使用媒体卡片、搜索、排序、播放页和剧照页。

第一阶段：将 Emby API Key 设置改成服务器地址、用户名、密码登录；保存 token、Emby Server Id、User Id 和设备信息；401 自动回登录页；修复连接测试和局域网错误提示。

第二阶段：实现本地目录来源。用户选择目录后保存 SAF 授权，支持隐藏文件夹开关，扫描视频，读取宽高、时长、编码等容器元数据，生成封面/缩略图，并提供本地剧照。Emby 的在线元数据不能自动出现在本地文件上；需要基于文件名、年份或用户选择匹配外部元数据，再缓存到本地。

第三阶段：实现 OpenList WebDAV 来源。保存 URL、账号和密码，浏览目录，过滤视频和隐藏目录，使用 HTTP Range 播放；对需要代理的 OpenList 配置显示“请在 OpenList 开启 Web Proxy 或 WebDAV Native Proxy”。

第四阶段：实现原生 SMB 来源。使用自定义 Android Development Build，加入 SMB 连接、目录浏览、视频 Range 读取和权限错误提示。SMB 账号密码单独安全存储。

当前技术边界：App 不再依赖 Termux、Python 或自建服务端；但“无服务端”不代表不需要连接源服务，Emby/OpenList/SMB 仍需在手机可达并提供媒体数据。GIF 编码、视频帧截图和部分本地元数据处理可能需要原生模块。
