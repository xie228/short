export type EmbySettings = {
  serverUrl: string;
  username: string;
  token: string;
  userId: string;
  serverId?: string;
  deviceId?: string;
};

export type EmbyLoginResult = {
  AccessToken?: string;
  ServerId?: string;
  User?: { Id?: string; Name?: string };
};

export type EmbyItem = {
  Id: string;
  Name?: string;
  Type?: string;
  ImageTags?: { Primary?: string; Thumb?: string; Backdrop?: string };
  BackdropImageTags?: string[];
  PrimaryImageAspectRatio?: number;
  RunTimeTicks?: number;
  DateCreated?: string;
  ParentId?: string;
  MediaSources?: Array<{ Id?: string; MediaStreams?: Array<{ Type?: string; Width?: number; Height?: number }> }>;
};

export type EmbyImage = { Name: string; Url: string; DeleteIndex?: number };

function cleanServerUrl(value: string) {
  const cleaned = value.trim().replace(/\/+$/, "");
  return cleaned.toLowerCase().endsWith("/emby") ? cleaned : `${cleaned}/emby`;
}

function deviceId() {
  return "emby-short-android";
}

export class EmbyClient {
  readonly settings: EmbySettings;
  readonly baseUrl: string;

  constructor(settings: EmbySettings) {
    this.settings = settings;
    this.baseUrl = cleanServerUrl(settings.serverUrl);
  }

  private authorization() {
    return `Emby UserId="${this.settings.userId}", Client="Emby Short", Device="Android", DeviceId="${this.settings.deviceId ?? deviceId()}", Version="1.0.0"`;
  }

  private url(path: string, params: Record<string, string | number | boolean | undefined> = {}) {
    const query = new URLSearchParams();
    Object.entries(params).forEach(([key, value]) => {
      if (value !== undefined && value !== "") query.set(key, String(value));
    });
    const suffix = query.toString();
    return `${this.baseUrl}${path}${suffix ? `?${suffix}` : ""}`;
  }

  private async fetchJson<T>(url: string, init: RequestInit = {}) {
    const response = await fetch(url, {
      ...init,
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: this.authorization(),
        ...(this.settings.token ? { "X-Emby-Token": this.settings.token } : {}),
        ...(init.headers ?? {}),
      },
    });
    if (!response.ok) {
      const message = await response.text().catch(() => "");
      if (response.status === 401) throw new Error("Emby 登录已失效，请重新登录");
      throw new Error(`Emby 请求失败（${response.status}）${message ? `：${message.slice(0, 120)}` : ""}`);
    }
    return (await response.json()) as T;
  }

  async login(username: string, password: string) {
    const response = await fetch(`${this.baseUrl}/Users/AuthenticateByName`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Emby Client="Emby Short", Device="Android", DeviceId="${deviceId()}", Version="1.0.0"`,
      },
      body: JSON.stringify({ Username: username.trim(), Pw: password }),
    });
    if (!response.ok) {
      if (response.status === 401 || response.status === 400) throw new Error("Emby 用户名或密码错误");
      const message = await response.text().catch(() => "");
      throw new Error(`Emby 登录失败（${response.status}）${message ? `：${message.slice(0, 120)}` : ""}`);
    }
    const data = (await response.json()) as EmbyLoginResult;
    if (!data.AccessToken || !data.User?.Id) throw new Error("Emby 登录返回内容不完整");
    return { token: data.AccessToken, userId: data.User.Id, serverId: data.ServerId, username: data.User.Name ?? username.trim() };
  }

  async testConnection() {
    return this.fetchJson<{ ServerName?: string; Version?: string }>(this.url("/System/Info"));
  }

  async getViews() {
    return this.fetchJson<{ Items?: EmbyItem[] }>(this.url(`/Users/${encodeURIComponent(this.settings.userId)}/Views`));
  }

  async getItems(options: { parentId?: string; search?: string; sortBy?: string } = {}) {
    return this.fetchJson<{ Items?: EmbyItem[]; TotalRecordCount?: number }>(this.url(`/Users/${encodeURIComponent(this.settings.userId)}/Items`, {
      ParentId: options.parentId,
      SearchTerm: options.search,
      SortBy: options.sortBy ?? "DateCreated",
      SortOrder: "Descending",
      Recursive: true,
      IncludeItemTypes: "Movie,Episode,Video",
      Fields: "PrimaryImageAspectRatio,RunTimeTicks,MediaSources,DateCreated",
      Limit: 80,
    }));
  }

  imageUrl(itemId: string, type: "Primary" | "Thumb" | "Backdrop" = "Primary", index?: number) {
    const params = new URLSearchParams({ api_key: this.settings.token });
    if (type !== "Primary") params.set("type", type);
    if (index !== undefined) params.set("index", String(index));
    return `${this.baseUrl}/Items/${encodeURIComponent(itemId)}/Images/${type}?${params.toString()}`;
  }

  streamUrl(itemId: string) {
    return `${this.url(`/Videos/${encodeURIComponent(itemId)}/stream`, { Static: true })}&api_key=${encodeURIComponent(this.settings.token)}`;
  }

  async getBackdrops(itemId: string) {
    const data = await this.fetchJson<EmbyItem>(this.url(`/Users/${encodeURIComponent(this.settings.userId)}/Items/${encodeURIComponent(itemId)}`));
    return (data.BackdropImageTags ?? []).map((_, index) => ({ Name: `Emby 剧照 ${index + 1}`, Url: this.imageUrl(itemId, "Backdrop", index), DeleteIndex: index } satisfies EmbyImage));
  }

  async deleteBackdrop(itemId: string, index: number) {
    await this.fetchJson(this.url(`/Items/${encodeURIComponent(itemId)}/Images/Backdrop/${index}`), { method: "DELETE" });
  }

  async uploadImage(itemId: string, kind: "Primary" | "Backdrop", base64: string) {
    const blob = await fetch(`data:image/jpeg;base64,${base64}`).then((response) => response.blob());
    const path = kind === "Primary" ? "Primary" : "Backdrop";
    const response = await fetch(this.url(`/Items/${encodeURIComponent(itemId)}/Images/${path}`), { method: "POST", headers: { "Content-Type": "image/jpeg", "X-Emby-Token": this.settings.token, Authorization: this.authorization() }, body: blob });
    if (!response.ok) throw new Error(`图片上传失败（${response.status}）`);
  }
}
