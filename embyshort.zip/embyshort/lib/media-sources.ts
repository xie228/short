import AsyncStorage from "@react-native-async-storage/async-storage";
import { Directory, File } from "expo-file-system";

export type LocalSource = { id: string; name: string; uri: string; includeHidden: boolean };
export type OpenListSource = { id: string; name: string; url: string; username: string; password: string; includeHidden: boolean };
export type SourceConfig = { locals: LocalSource[]; openlists: OpenListSource[] };

const KEY = "emby-short-media-sources-v1";
const VIDEO_EXTENSIONS = new Set(["mp4", "mkv", "mov", "avi", "webm", "m4v", "ts", "m2ts"]);

export async function loadSources(): Promise<SourceConfig> {
  const raw = await AsyncStorage.getItem(KEY);
  return raw ? JSON.parse(raw) as SourceConfig : { locals: [], openlists: [] };
}

export async function saveSources(config: SourceConfig) {
  await AsyncStorage.setItem(KEY, JSON.stringify(config));
}

export async function pickLocalDirectory(includeHidden = false): Promise<LocalSource | null> {
  const directory = await Directory.pickDirectoryAsync();
  if (!directory) return null;
  const name = directory.name || "手机视频";
  return { id: `local:${directory.uri}`, name, uri: directory.uri, includeHidden };
}

export type LocalVideo = { id: string; name: string; uri: string; size?: number; modified?: number };

export function isVideoName(name: string) {
  const dot = name.lastIndexOf(".");
  return dot >= 0 && VIDEO_EXTENSIONS.has(name.slice(dot + 1).toLowerCase());
}

export function isHiddenName(name: string) {
  return name.startsWith(".") || name.startsWith("_");
}

export function scanLocalDirectory(source: LocalSource, maxDepth = 3): LocalVideo[] {
  const result: LocalVideo[] = [];
  const walk = (directory: Directory, depth: number) => {
    if (depth > maxDepth) return;
    let entries: (Directory | File)[] = [];
    try { entries = directory.list(); } catch { return; }
    for (const entry of entries) {
      if (isHiddenName(entry.name) && !source.includeHidden) continue;
      if (entry instanceof Directory) walk(entry, depth + 1);
      else if (isVideoName(entry.name)) result.push({ id: entry.uri, name: entry.name, uri: entry.uri, size: entry.size ?? undefined, modified: entry.modificationTime ?? undefined });
    }
  };
  walk(new Directory(source.uri), 0);
  return result;
}

export async function listOpenListDirectory(source: OpenListSource, path = "/") {
  const base = source.url.replace(/\/+$/, "");
  const target = `${base}/dav${path === "/" ? "/" : path}`;
  const auth = typeof btoa === "function" ? btoa(`${source.username}:${source.password}`) : "";
  const response = await fetch(target, { method: "PROPFIND", headers: { Depth: "1", ...(auth ? { Authorization: `Basic ${auth}` } : {}) } });
  if (!response.ok) throw new Error(`OpenList WebDAV 请求失败（${response.status}）`);
  const xml = await response.text();
  const items: Array<{ name: string; href: string; isDirectory: boolean }> = [];
  for (const match of xml.matchAll(/<[^>]*response[^>]*>([\s\S]*?)<\/[^>]*response>/gi)) {
    const block = match[1];
    const href = block.match(/<[^>]*href[^>]*>([\s\S]*?)<\/[^>]*href>/i)?.[1]?.trim();
    if (!href) continue;
    const decoded = href.replace(/&amp;/g, "&");
    const name = decodeURIComponent(decoded.split("/").filter(Boolean).pop() ?? "");
    const isDirectory = /collection/i.test(block);
    if (name) items.push({ name, href: decoded, isDirectory });
  }
  return items;
}
