import AsyncStorage from "@react-native-async-storage/async-storage";
import * as SecureStore from "expo-secure-store";
import { Platform } from "react-native";

import type { EmbySettings } from "./emby-client";

const SETTINGS_KEY = "emby-short-settings-v2";
const TOKEN_KEY = "emby-short-emby-token-v2";

export async function loadSettings(): Promise<EmbySettings> {
  const raw = await AsyncStorage.getItem(SETTINGS_KEY);
  const saved = raw ? (JSON.parse(raw) as Partial<EmbySettings>) : {};
  const token = Platform.OS === "web" ? ((await AsyncStorage.getItem(TOKEN_KEY)) ?? "") : ((await SecureStore.getItemAsync(TOKEN_KEY)) ?? "");
  return { serverUrl: saved.serverUrl ?? "", username: saved.username ?? "", token, userId: saved.userId ?? "", serverId: saved.serverId, deviceId: saved.deviceId ?? "emby-short-android" };
}

export async function saveSettings(settings: EmbySettings) {
  await AsyncStorage.setItem(SETTINGS_KEY, JSON.stringify({ serverUrl: settings.serverUrl, username: settings.username, userId: settings.userId, serverId: settings.serverId, deviceId: settings.deviceId }));
  if (Platform.OS === "web") await AsyncStorage.setItem(TOKEN_KEY, settings.token);
  else await SecureStore.setItemAsync(TOKEN_KEY, settings.token);
}

export async function clearSettings() {
  await AsyncStorage.removeItem(SETTINGS_KEY);
  if (Platform.OS === "web") await AsyncStorage.removeItem(TOKEN_KEY);
  else await SecureStore.deleteItemAsync(TOKEN_KEY);
}
