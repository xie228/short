import type { EmbyClient, EmbyItem } from "./emby-client";
import { listOpenListDirectory, scanLocalDirectory, type OpenListSource, type LocalSource } from "./media-sources";

export type MediaSourceKind = "emby" | "local" | "openlist";

export type UnifiedMedia = {
  id: string;
  name: string;
  source: MediaSourceKind;
  /** 播放地址：Emby 直链 / 本地 file:// / WebDAV http(s) */
  streamUri: string;
  /** WebDAV Basic 认证头等额外播放请求头 */
  headers?: Record<string, string>;
  /** 海报地址；本地来源暂无缩略图时为空 */
  imageUrl?: string;
  /** 从文件名解析出的元数据 */
  title?: string;
  year?: number;
  durationTicks?: number;
  /** Emby 项目 Id（仅 emby 来源），用于截图上传 */
  embyItemId?: string;
  /** 来源目录名，用于分组展示 */
  groupName?: string;
};

import { parseVideoName } from "./video-name";

export { parseVideoName };

function webdavAuthHeader(source: OpenListSource): Record<string, string> {
  const raw = `${source.username}:${source.password}`;
  const auth = typeof btoa === "function" ? btoa(raw) : Buffer.from(raw, "utf8").toString("base64");
  return { Authorization: `Basic ${auth}` };
}

/** OpenList WebDAV href（可能是绝对路径 /dav/xxx）转换为可直接访问的 URL */
export function openListHrefToUrl(source: OpenListSource, href: string): string {
  const base = source.url.replace(/\/+$/, "");
  if (/^https?:\/\//i.test(href)) return href;
  const path = href.startsWith("/") ? href : `/${href}`;
  return `${base}${path}`;
}

export function localVideosToMedia(source: LocalSource): UnifiedMedia[] {
  return scanLocalDirectory(source).map((video) => {
    const meta = parseVideoName(video.name);
    return {
      id: video.id,
      name: video.name,
      source: "local" as const,
      streamUri: video.uri,
      title: meta.title,
      year: meta.year,
      groupName: source.name,
    };
  });
}

export async function openListVideosToMedia(source: OpenListSource, path = "/"): Promise<UnifiedMedia[]> {
  const entries = await listOpenListDirectory(source, path);
  const headers = webdavAuthHeader(source);
  return entries
    .filter((entry) => !entry.isDirectory)
    .map((entry) => {
      const fileName = decodeURIComponent(entry.href.split("/").filter(Boolean).pop() ?? entry.name);
      const meta = parseVideoName(fileName);
      return {
        id: `openlist:${entry.href}`,
        name: fileName,
        source: "openlist" as const,
        streamUri: openListHrefToUrl(source, entry.href),
        headers,
        title: meta.title,
        year: meta.year,
        groupName: source.name,
      };
    });
}

export function embyItemsToMedia(items: EmbyItem[], client: EmbyClient): UnifiedMedia[] {
  return items.map((item) => ({
    id: `emby:${item.Id}`,
    name: item.Name ?? "未命名视频",
    source: "emby" as const,
    streamUri: client.streamUrl(item.Id),
    headers: { "X-Emby-Token": client.settings.token },
    imageUrl: client.imageUrl(item.Id),
    title: item.Name,
    durationTicks: item.RunTimeTicks,
    embyItemId: item.Id,
  }));
}

export function sourceLabel(source: MediaSourceKind): string {
  return source === "emby" ? "Emby" : source === "local" ? "本地" : "OpenList";
}
