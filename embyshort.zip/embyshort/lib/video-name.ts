/** 纯函数：视频文件名元数据解析（便于 Node 测试） */
/**
 * 从视频文件名解析标题与年份，用于本地/OpenList 来源的元数据匹配。
 * 例："Inception.2010.1080p.BluRay.mkv" -> { title: "Inception", year: 2010 }
 */
export function parseVideoName(fileName: string): { title: string; year?: number } {
  const withoutExt = fileName.replace(/\.[a-z0-9]+$/i, "");
  // 年份之后的内容通常是分辨率/压制组等标签，截断
  const yearMatch = withoutExt.match(/(?:^|[\s.\-[(])((?:19|20)\d{2})(?=[\s.\-)\]]|$)/);
  const year = yearMatch ? Number(yearMatch[1]) : undefined;
  const yearIndex = yearMatch?.index ?? -1;
  let title = yearMatch && yearIndex > 0 ? withoutExt.slice(0, yearIndex) : withoutExt;
  if (!(yearMatch && yearIndex > 0)) {
    // 无年份时截断常见标签
    title = title.split(/[\s.\-]\(?(?:1080p|720p|2160p|4k|bluray|web[\s-]?dl|hdr|x264|x265|hevc|aac)\b/i)[0];
  }
  title = title.replace(/[._]+/g, " ").replace(/\s{2,}/g, " ").replace(/^[\s\-\[\(]+|[\s\-\]\)]+$/g, "").trim();
  return { title: title || withoutExt.replace(/[._]+/g, " "), year };
}

