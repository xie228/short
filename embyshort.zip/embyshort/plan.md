# Emby Short 独立 Android App 计划

## 产品范围

将现有 `emby_short.py` 中已经确认的功能重做为独立 Android App。App 直接访问用户配置的 Emby 服务，不携带 Termux、Python、ffmpeg 服务或 WebView 服务端。Emby 地址、API Key、用户 ID 在 App 设置中配置，并使用 SecureStore 保存 API Key。

## 三种视觉方向

- **浅色玻璃控制台**（概率 0.07）：以白色内容面板、蓝色强调色和轻薄玻璃胶囊控制键为主，强调清晰和易读。
- **影院票根**（概率 0.05）：以深色影院背景、海报卡片和暖色票根信息为主，强调沉浸感。
- **信息流播放器**（概率 0.08）：以媒体瀑布流、紧凑筛选条和悬浮播放控制为主，强调高效浏览。

本项目选择 **浅色玻璃控制台**，因为用户已明确要求整体保持亮色 UI，同时希望控制键统一为玻璃拟态胶囊风格。

## 设计

- **Design Movement**：Light Glassmorphism，使用真实内容卡片配合轻微透明、模糊和内高光，不使用大面积深色播放器底板。
- **Core Principles**：亮色高对比、单手可操作、控制键统一、播放状态明确。
- **Color Philosophy**：背景使用冷白和浅蓝灰，蓝色只用于选中态和关键操作，文字使用深蓝灰，保证亮色页面上的可读性。
- **Layout Paradigm**：上方固定媒体库/搜索区，中部为可滚动媒体流，播放时切换为全屏或竖屏分区播放器；控制区使用悬浮胶囊，不让列表遮挡按钮。
- **Signature Elements**：玻璃拟态胶囊控制键、带播放进度的媒体卡片、剧照时间水印。
- **Interaction Philosophy**：所有高频动作都在拇指可达区域；播放/暂停只用图标区分，封面、剧照、GIF 使用分层菜单，删除剧照必须二次确认。
- **Animation**：卡片轻微淡入，按钮按下缩放到 0.94，播放器进入/退出使用短时淡入，避免影响视频操作。
- **Typography System**：系统无衬线字体，标题 20–24px 等级，媒体标题 14–16px，辅助信息 11–13px；中文保持清晰字重，不使用装饰字体。
- **Brand Essence**：面向 Emby 用户的轻量短视频媒体浏览器，直接、清晰、好操作；人格为清爽、可靠、利落。
- **Brand Voice**：按钮使用短动词，如“播放”“剧照”“保存”；提示明确说明结果，如“剧照已上传到 Emby”。
- **Wordmark & Logo**：方形浅蓝底，中央为白色播放三角与短横胶囊组合，适合 Android 启动器和小尺寸识别。
- **Signature Brand Color**：`#3B82F6` 亮蓝，作为 Emby Short 的操作强调色。

## 实现方式

- 使用初始化的 Expo Router / React Native / TypeScript starter，不替换固定移动端框架。
- 直接使用 Emby REST API：Views、Items、Images、Videos stream、Backdrop 上传/删除等接口。
- 使用 `expo-video` 播放 Emby 视频流，使用 Safe Area 和屏幕方向状态实现竖屏播放布局；全屏先实现可靠的 App 内播放器全屏布局，保留后续原生 fullscreen 扩展点。
- 使用 `expo-image` 加载海报和剧照，使用 `expo-secure-store` 保存 API Key，服务器地址和用户 ID可保存为普通本地设置。
- 使用 `ViewShot` 不可用时的原生替代方案：剧照截图先以视频当前帧/播放器快照能力为首选；若当前 Expo 版本无法直接抓取视频帧，则保留上传入口并明确在设备验证阶段处理兼容性。时间水印在 React Native Canvas/Skia 能力允许时绘制在截图上。
- GIF 动态封面在独立 App 中优先走 Emby 允许的上传路径；若设备端无法编码 GIF，则提供兼容的错误提示，不引入 Termux 或 Python 后端。

## 页面和模块

```text
app/
  (tabs)/index.tsx        媒体库、搜索、排序、媒体卡片
  (tabs)/_layout.tsx      单一主 Tab，隐藏无关模板入口
  player/[id].tsx         播放器、竖屏布局、控制栏、剧照与封面菜单
  settings.tsx            Emby 地址/API Key/用户 ID 配置和连接测试
components/
  GlassButton.tsx         统一玻璃拟态胶囊按钮
  MediaCard.tsx           海报卡片和播放状态
  StillGallery.tsx        Emby Backdrop 剧照、预览、删除
  VideoPlayer.tsx         expo-video 封装和播放控制
lib/
  emby-client.ts          Emby REST API、认证头和数据模型
  settings-store.ts       SecureStore/AsyncStorage 配置读写
  capture.ts              截帧、水印和上传边界
constants/
  theme.ts                亮色色板、间距和圆角
assets/images/             Android 启动图标和启动画面
```

## 交付流程

先完成首页、设置、Emby 读取和播放器主流程，再加入剧照管理和封面菜单，最后运行 TypeScript 检查、Lint、测试和 Expo Web 预览。Android APK/AAB 由 Dashboard 使用已接受的 checkpoint 构建；本 Sandbox 不直接运行发布版 Android 构建。
