import { describe, expect, it } from "vitest";

import { parseVideoName } from "../lib/video-name";

describe("parseVideoName", () => {
  it("解析年份并截断压制标签", () => {
    expect(parseVideoName("Inception.2010.1080p.BluRay.x264.mkv")).toEqual({ title: "Inception", year: 2010 });
  });

  it("空格分隔的中文文件名", () => {
    const result = parseVideoName("流浪地球 2 (2023) 4K.mp4");
    expect(result.year).toBe(2023);
    expect(result.title).toContain("流浪地球");
  });

  it("无年份时截断分辨率标签", () => {
    const result = parseVideoName("My.Video.1080p.WEB-DL.mkv");
    expect(result.title).toBe("My Video");
    expect(result.year).toBeUndefined();
  });

  it("纯文件名原样保留", () => {
    expect(parseVideoName("假期记录.mp4")).toEqual({ title: "假期记录", year: undefined });
  });
});
